<?= 
$para=" Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore, nostrum fuga natus alias sit nobis sequi, magnam inventore ab ipsa magni illum itaque tempora. Esse cupiditate impedit fuga ipsam earum.";

$para1="Brijesh kumar pandey";

?>