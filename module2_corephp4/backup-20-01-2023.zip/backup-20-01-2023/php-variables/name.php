<?php 
$name="Yash haraniya";
$name1="Dixit Radadiya";
$name2="Nirav sakariya";
$name3="Hiten Vora";
$name4="Milan sarvaiya";
$name5="Jigna vaghasiya";
echo $name."<br>".$name1."<br>".$name2."<br>".$name3."<br>".$name4."<br>".$name5;

?>