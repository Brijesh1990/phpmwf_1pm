<?php 
$ab="brijesh";
echo $ab;
?>